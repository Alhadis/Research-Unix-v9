sgn(arg)
{
	return(arg<0? -1: arg==0? 0: 1);
}

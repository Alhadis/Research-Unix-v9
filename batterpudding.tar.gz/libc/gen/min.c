min(a,b)
{
	return (a<b? a: b);
}

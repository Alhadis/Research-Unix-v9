long
labs(x)
long x;
{
	if(x<0)
		x = -x;
	return x;
}

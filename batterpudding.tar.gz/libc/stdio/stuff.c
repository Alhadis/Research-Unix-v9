/* @(#)stuff.c	4.1 (Berkeley) 12/21/80 */
int	yyportlib	=1;

wdleng()
{
	return(32);
}

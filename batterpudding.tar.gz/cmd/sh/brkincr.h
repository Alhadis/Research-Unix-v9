/*	@(#)brkincr.h	1.2	*/
/*	3.0 SID #	1.1	*/
#define BRKINCR 01000
#define BRKMAX 04000

/*	@(#)timeout.h	1.3	*/
/*
 *	UNIX shell
 *
 *	Bell Telephone Laboratories
 *
 */

#define TIMEOUT 	0	/* seconds elapsing before log-off (normal) */
#define MAILCHECK	"600"	/* 10 minutes */


#define	ABS(x)	((x<0) ? -(x) : x)

#define	MAX_EXPONENT	88.0
#define MIN_EXPONENT	-88.0

#define	GREATEST 1.701411834604692293e38

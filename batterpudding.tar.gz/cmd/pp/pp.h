#define	KEYWORD		1
#define	COMMENT		2
#define	FUNCTION	3
#define	OTHER		4
#define	DISPLAYCOMMENT	5
extern char yytext[];

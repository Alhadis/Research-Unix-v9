#include <string.h>
extern char *index(), *rindex();

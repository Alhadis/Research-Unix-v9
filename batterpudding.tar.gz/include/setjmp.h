#ifdef vax
typedef int jmp_buf[10];
#endif

#ifdef mc68000
typedef int jmp_buf[14];
#endif

extern char
	*strcpy(),
	*strncpy(),
	*strcat(),
	*strncat(),
	*strchr(),
	*strrchr(),
	*strpbrk(),
	*strtok(),
	*strdup();
extern int
	strcmp(),
	strncmp(),
	strlen(),
	strspn(),
	strcspn();

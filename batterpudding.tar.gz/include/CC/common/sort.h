overload sort;
void sort(common*[]);	/* sort a vector of object pointers */
void sort(common[]);	/* sort a vector of objects */


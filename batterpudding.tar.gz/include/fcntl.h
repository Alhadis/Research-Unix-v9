/* just the system 5 place holder */
#define O_RDONLY	0
#define O_WRONLY	1
#define O_RDWR		2

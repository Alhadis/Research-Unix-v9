#define E_TERMCAP	"/etc/termcap"
#define usrpath(file) "/usr/file"
